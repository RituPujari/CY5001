#!/bin/bash

MODE=$1

if [ "$MODE" == "-s" ]; then

    PRIVKEY=$2
    FILE=$3
    SIGOUT=$4

    openssl dgst -sha256 -sign "$PRIVKEY" -out "$SIGOUT" "$FILE"
    exit $?

elif [ "$MODE" == "-v" ]; then

    PUBKEY=$2
    FILE=$3
    SIGFILE=$4

    openssl dgst -sha256 -verify "$PUBKEY" -signature "$SIGFILE" "$FILE"
    exit $?

else
    echo "Invalid option"
    exit 1
fi
