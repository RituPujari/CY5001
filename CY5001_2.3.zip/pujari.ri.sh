#!/bin/bash

MODE=$1

if [ "$MODE" == "-e" ]; then

    PUBKEY=$2
    PLAINTEXT=$3
    OUTENC=$4
    OUTKEY=$5

    SESSION_KEY=$(mktemp) 

    openssl rand -out "$SESSION_KEY" 24

    openssl enc -aes-192-ctr -nosalt -iter 1000000 \
        -in "$PLAINTEXT" \
        -out "$OUTENC" \
        -pass file:"$SESSION_KEY"

      openssl pkeyutl -encrypt \
        -pubin -inkey "$PUBKEY" \
        -in "$SESSION_KEY" \
        -out "$OUTKEY"

    rm -f "$SESSION_KEY"

elif [ "$MODE" == "-d" ]; then

    PRIVKEY=$2
    ENCFILE=$3
    ENCKEY=$4
    OUTFILE=$5

    SESSION_KEY=$(mktemp)

    openssl pkeyutl -decrypt \
        -inkey "$PRIVKEY" \
        -in "$ENCKEY" \
        -out "$SESSION_KEY"

    openssl enc -d -aes-192-ctr -nosalt -iter 1000000 \
        -in "$ENCFILE" \
        -out "$OUTFILE" \
        -pass file:"$SESSION_KEY"

    rm -f "$SESSION_KEY"

else
    echo "Invalid option"
    exit 1
fi
