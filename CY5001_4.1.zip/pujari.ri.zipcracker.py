#!/usr/bin/python3

import zipfile # Library to extract zip files
import time # Library to measure the time spent in the cracking process
import sys # Library to access the arguments of the script

zfile = sys.argv[1]
dfile = sys.argv[2]
filezip = zipfile.ZipFile(zfile) # We used the "zipfile" library to open the zipped file.
passFile = open(dfile) # opening the dictionary file.

count = 0
start_time = time.time() # record start time before cracking begins

for line in passFile:
    password = line.strip("\n") # removing the end of line
    codedpass = bytes(password, 'utf-8') # password encoded in binary
    count = count + 1
    try: # trying the password using "zipfile" library
        filezip.extractall(pwd=codedpass)
    except:
        pass
    else:
        elapsed = time.time() - start_time
        print ("[------- Password Found ---------] --> " + password)
        print ("Time consumed: " + str(elapsed) + " seconds")
        print ("Passwords attempted: " + str(count) + ". At " + str(count/elapsed) + " tries per second")
        exit(0)

print ("[-] Password not found. Attempted: " + str(count))
